 
### app/services/redshift_client.py ###
import boto3
import pandas as pd
from app.utils.logger import setup_logger

logger = setup_logger('redshift_client')

class RedshiftClient:
    def __init__(self, conn_string):
        self.conn_string = conn_string

    async def create_table(self, table_name, schema):
        """Create new table in Redshift"""
        try:
            create_query = self._generate_create_query(table_name, schema)
            async with self._get_connection() as conn:
                await conn.execute(create_query)
            logger.info(f"Created table: {table_name}")
        except Exception as e:
            logger.error(f"Error creating table: {str(e)}")
            raise

    async def append_data(self, table_name, data_path):
        """Append data to existing table"""
        try:
            # Backup existing table
            await self._backup_table(table_name)
            
            # Load and append new data
            df = pd.read_csv(data_path)
            async with self._get_connection() as conn:
                await conn.execute(
                    f"COPY {table_name} FROM '{data_path}' "
                    "CREDENTIALS 'aws_iam_role=arn:aws:iam::...' "
                    "CSV IGNOREHEADER 1;"
                )
            logger.info(f"Appended data to: {table_name}")
        except Exception as e:
            logger.error(f"Error appending data: {str(e)}")
            raise