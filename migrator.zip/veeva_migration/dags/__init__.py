# dags/__init__.py
"""
DAGs package for Veeva data migration pipeline.
"""
from .veeva_migration_dag import dag

__all__ = ['dag']
