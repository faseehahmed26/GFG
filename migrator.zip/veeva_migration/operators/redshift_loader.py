import os
from typing import Dict, Any
import pandas as pd
from sqlalchemy import create_engine
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from utils.logger import PipelineLogger

logger = PipelineLogger("redshift_loader")

class RedshiftLoader(BaseOperator):
    @apply_defaults
    def __init__(
        self,
        input_file: str,
        table_name: str,
        schema: str,
        redshift_conn_id: str,
        load_mode: str = 'append',
        *args,
        **kwargs
    ) -> None:
        super().__init__(*args, **kwargs)
        self.input_file = input_file
        self.table_name = table_name
        self.schema = schema
        self.redshift_conn_id = redshift_conn_id
        self.load_mode = load_mode

    def _get_redshift_connection(self) -> str:
        """Get Redshift connection string."""
        conn = os.environ.get('REDSHIFT_CONNECTION_STRING')
        if not conn:
            raise ValueError("Redshift connection string not found in environment variables")
        return conn

    def _create_temp_table(self, engine: Any, df: pd.DataFrame, temp_table: str) -> None:
        """Create temporary table for staging data."""
        df.head(0).to_sql(
            temp_table,
            engine,
            schema=self.schema,
            if_exists='replace',
            index=False
        )

    def _load_data_to_temp_table(self, engine: Any, df: pd.DataFrame, temp_table: str) -> None:
        """Load data to temporary table."""
        connection = engine.raw_connection()
        try:
            with connection.cursor() as cur:
                output = StringIO()
                df.to_csv(output, sep=',', header=False, index=False)
                output.seek(0)
                cur.copy_expert(
                    f"""COPY {self.schema}.{temp_table}
                    FROM STDIN WITH CSV""",
                    output
                )
            connection.commit()
        finally:
            connection.close()

    def _merge_temp_to_target(self, engine: Any, temp_table: str) -> None:
        """Merge data from temporary table to target table."""
        merge_query = f"""
        BEGIN TRANSACTION;
        
        DELETE FROM {self.schema}.{self.table_name}
        USING {self.schema}.{temp_table}
        WHERE {self.schema}.{self.table_name}.id = {self.schema}.{temp_table}.id;
        
        INSERT INTO {self.schema}.{self.table_name}
        SELECT * FROM {self.schema}.{temp_table};
        
        DROP TABLE {self.schema}.{temp_table};
        
        COMMIT;
        """
        
        with engine.begin() as conn:
            conn.execute(merge_query)

    def execute(self, context: Dict[str, Any]) -> None:
        """Execute the operator."""
        try:
            # Read input data
            df = pd.read_csv(self.input_file)
            
            # Create engine
            engine = create_engine(self._get_redshift_connection())
            
            if self.load_mode == 'replace':
                # Direct replacement
                df.to_sql(
                    self.table_name,
                    engine,
                    schema=self.schema,
                    if_exists='replace',
                    index=False
                )
            else:
                # Incremental load using temp table
                temp_table = f"{self.table_name}_temp"
                self._create_temp_table(engine, df, temp_table)
                self._load_data_to_temp_table(engine, df, temp_table)
                self._merge_temp_to_target(engine, temp_table)
            
            logger.info("Successfully loaded data to Redshift", {
                "table": f"{self.schema}.{self.table_name}",
                "records": len(df),
                "mode": self.load_mode
            })
            
        except Exception as e:
            logger.error("Failed to load data to Redshift", {"error": str(e)})
            raise