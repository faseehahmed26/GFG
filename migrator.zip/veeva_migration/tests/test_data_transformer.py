# tests/test_data_transformer.py
import pytest
import pandas as pd
from operators.data_transformer import DataTransformer

@pytest.fixture
def sample_data():
    return [
        {
            'id': '1',
            'name': 'Test',
            'modified_date__v': '2024-01-01'
        }
    ]

def test_transformer_init():
    transformer = DataTransformer(
        task_id='test',
        input_file='test.json',
        output_path='output',
        table_name='test_table'
    )
    assert transformer.table_name == 'test_table'
    assert transformer.input_file == 'test.json'

def test_flatten_nested_dict():
    transformer = DataTransformer(
        task_id='test',
        input_file='test.json',
        output_path='output',
        table_name='test_table'
    )
    
    nested_dict = {
        'parent': {
            'child': 'value'
        }
    }
    
    result = transformer._flatten_nested_dict(nested_dict)
    assert result == {'parent_child': 'value'}