# tests/test_redshift_loader.py
import pytest
from unittest.mock import Mock, patch
from operators.redshift_loader import RedshiftLoader
import pandas as pd
def test_redshift_loader_init():
    loader = RedshiftLoader(
        task_id='test',
        input_file='test.csv',
        table_name='test_table',
        schema='test_schema',
        redshift_conn_id='test_conn'
    )
    assert loader.table_name == 'test_table'
    assert loader.schema == 'test_schema'

@patch('operators.redshift_loader.create_engine')
def test_load_data_to_temp_table(mock_engine):
    mock_connection = Mock()
    mock_engine.return_value.raw_connection.return_value = mock_connection
    
    loader = RedshiftLoader(
        task_id='test',
        input_file='test.csv',
        table_name='test_table',
        schema='test_schema',
        redshift_conn_id='test_conn'
    )
    
    test_df = pd.DataFrame({'col1': [1, 2], 'col2': ['a', 'b']})
    loader._load_data_to_temp_table(mock_engine, test_df, 'temp_table')
    assert mock_connection.commit.called