import os
from datetime import datetime
import json
from typing import Dict, Any, Optional
import requests
import yaml
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from utils.logger import PipelineLogger

logger = PipelineLogger("veeva_extractor")

class VeevaExtractor(BaseOperator):
    @apply_defaults
    def __init__(
        self,
        endpoint: str,
        config_path: str,
        output_path: str,
        last_snapshot_date: Optional[str] = None,
        *args,
        **kwargs
    ) -> None:
        super().__init__(*args, **kwargs)
        self.endpoint = endpoint
        self.config_path = config_path
        self.output_path = output_path
        self.last_snapshot_date = last_snapshot_date
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        try:
            with open(self.config_path, 'r') as file:
                return yaml.safe_load(file)['veeva_api']
        except Exception as e:
            logger.error("Failed to load config", {"error": str(e)})
            raise

    def _get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers for Veeva API."""
        return {
            'Authorization': f'Bearer {os.getenv("VEEVA_API_TOKEN")}',
            'Content-Type': 'application/json'
        }

    def _make_api_request(self, url: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Make HTTP request to Veeva API."""
        try:
            response = requests.get(
                url,
                headers=self._get_auth_headers(),
                params=params
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error("API request failed", {
                "url": url,
                "error": str(e),
                "status_code": getattr(e.response, 'status_code', None)
            })
            raise

    def _fetch_data(self, endpoint_config: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch data from Veeva API for given endpoint."""
        base_url = self.config['base_url']
        version = self.config['version']
        path = endpoint_config['path']
        
        url = f"{base_url}/api/{version}{path}"
        
        params = {
            'page[size]': 100,
            'page[number]': 1
        }

        if self.last_snapshot_date:
            params['filter'] = f"modified_date__v>={self.last_snapshot_date}"

        all_data = []
        total_pages = 1
        current_page = 1

        while current_page <= total_pages:
            response_data = self._make_api_request(url, params)
            
            if current_page == 1:
                total_pages = response_data.get('meta', {}).get('total_pages', 1)
            
            all_data.extend(response_data.get('data', []))
            current_page += 1
            params['page[number]'] = current_page

        return all_data

    def execute(self, context: Dict[str, Any]) -> None:
        """Execute the operator."""
        try:
            # Create output directory if it doesn't exist
            os.makedirs(self.output_path, exist_ok=True)

            # Get endpoint configuration
            endpoint_config = self.config['endpoints'].get(self.endpoint)
            if not endpoint_config:
                raise ValueError(f"No configuration found for endpoint: {self.endpoint}")

            # Fetch data
            data = self._fetch_data(endpoint_config)

            # Save data to file
            output_file = os.path.join(
                self.output_path,
                f"{self.endpoint}_{datetime.now().strftime('%Y%m%d')}.json"
            )
            
            with open(output_file, 'w') as f:
                json.dump(data, f, indent=2)

            logger.info(f"Successfully extracted data for {self.endpoint}", {
                "records": len(data),
                "output_file": output_file
            })

            # Update task instance with output file location
            context['task_instance'].xcom_push(
                key=f'{self.endpoint}_output_file',
                value=output_file
            )
        except Exception as e:
            logger.error("Failed to extract data", {
                "endpoint": self.endpoint,
                "error": str(e)
            })
            raise