# app/routes/__init__.py
from . import pipeline
from . import database

blueprints = [
    (pipeline.bp, '/api/pipeline'),
    (database.bp, '/api/database')
]



