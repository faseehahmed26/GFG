import logging
import json
from datetime import datetime
from typing import Any, Dict, Optional

class PipelineLogger:
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Create handlers
        console_handler = logging.StreamHandler()
        file_handler = logging.FileHandler(f'logs/{name}_{datetime.now().strftime("%Y%m%d")}.log')
        
        # Create formatters and add it to handlers
        log_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(log_format)
        file_handler.setFormatter(log_format)
        
        # Add handlers to the logger
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

    def _format_message(self, message: str, context: Optional[Dict[str, Any]] = None) -> str:
        if context:
            return f"{message} - Context: {json.dumps(context)}"
        return message

    def info(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.logger.info(self._format_message(message, context))

    def error(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.logger.error(self._format_message(message, context))

    def warning(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.logger.warning(self._format_message(message, context))

    def debug(self, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        self.logger.debug(self._format_message(message, context))