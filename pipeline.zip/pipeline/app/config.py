 
# app/config.py
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

class Config:
    # API Configuration
    VEEVA_URL = os.getenv('VEEVA_URL')
    VEEVA_TOKEN = os.getenv('VEEVA_TOKEN')
    
    # AWS/Redshift Configuration
    REDSHIFT_HOST = os.getenv('REDSHIFT_HOST')
    REDSHIFT_PORT = os.getenv('REDSHIFT_PORT')
    REDSHIFT_DB = os.getenv('REDSHIFT_DB')
    REDSHIFT_USER = os.getenv('REDSHIFT_USER')
    REDSHIFT_PASSWORD = os.getenv('REDSHIFT_PASSWORD')
    AWS_ACCESS_KEY = os.getenv('AWS_ACCESS_KEY')
    AWS_SECRET_KEY = os.getenv('AWS_SECRET_KEY')
    
    # Directory Configuration
    DATA_DIR = BASE_DIR / 'data'
    RAW_DIR = DATA_DIR / 'raw'
    PROCESSED_DIR = DATA_DIR / 'processed'
    BACKUP_DIR = DATA_DIR / 'backups'
    LOG_DIR = BASE_DIR / 'logs'

    # Ensure directories exist
    for dir_path in [RAW_DIR, PROCESSED_DIR, BACKUP_DIR, LOG_DIR]:
        dir_path.mkdir(parents=True, exist_ok=True)
