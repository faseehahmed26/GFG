 
# tests/test_data_processor.py
import pytest
import pandas as pd
import tempfile
from pathlib import Path
from app.services.data_processor import DataProcessor

@pytest.fixture
def temp_dirs():
    with tempfile.TemporaryDirectory() as raw_dir:
        with tempfile.TemporaryDirectory() as processed_dir:
            yield Path(raw_dir), Path(processed_dir)

@pytest.fixture
def sample_data():
    return [
        {
            "id": "app_001",
            "name": "Test Application",
            "value": None
        }
    ]

def test_process_data_success(temp_dirs, sample_data):
    raw_dir, processed_dir = temp_dirs
    processor = DataProcessor(raw_dir, processed_dir)
    
    output_path = processor.process_data(sample_data, "applications")
    
    assert Path(output_path).exists()
    df = pd.read_csv(output_path)
    assert 'id' in df.columns
    assert len(df) == 1
    assert df['id'].iloc[0] == 'app_001'

def test_process_data_null_handling(temp_dirs):
    raw_dir, processed_dir = temp_dirs
    processor = DataProcessor(raw_dir, processed_dir)
    data = [{"id": "test", "value": None}]
    
    output_path = processor.process_data(data, "test")
    df = pd.read_csv(output_path)
    assert df['value'].iloc[0] == 0  # Verify numeric null handling
