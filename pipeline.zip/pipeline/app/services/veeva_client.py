 
### app/services/veeva_client.py ###
from datetime import datetime
import requests
from app.utils.logger import setup_logger

logger = setup_logger('veeva_client')

class VeevaClient:
    def __init__(self, base_url, auth_token):
        self.base_url = base_url
        self.headers = {'Authorization': f'Bearer {auth_token}'}

    async def fetch_hierarchical_data(self, root_type, start_date):
        """Fetch hierarchical data from Veeva API"""
        try:
            root_data = await self._fetch_data(
                f'/api/v1/{root_type}',
                params={'modified_date': start_date}
            )
            
            for item in root_data:
                children = await self._fetch_children(item['id'], root_type)
                item['children'] = children
                
            return root_data
        except Exception as e:
            logger.error(f"Error fetching hierarchical data: {str(e)}")
            raise