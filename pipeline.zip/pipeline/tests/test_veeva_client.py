 
# tests/test_veeva_client.py
import pytest
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock
from app.services.veeva_client import VeevaClient

# Test fixtures moved directly into test file
@pytest.fixture
def sample_data():
    return [
        {
            "id": "app_001",
            "name": "Test Application",
            "status": "Active",
            "created_date": "2024-01-01",
            "children": [
                {
                    "id": "prod_001",
                    "name": "Test Product",
                    "type": "Device"
                }
            ]
        }
    ]

@pytest.fixture
def veeva_client():
    return VeevaClient("https://test.veevavault.com", "test_token")

@pytest.mark.asyncio
async def test_fetch_hierarchical_data_success(veeva_client, sample_data):
    with patch.object(veeva_client, '_fetch_data') as mock_fetch:
        mock_fetch.return_value = sample_data
        result = await veeva_client.fetch_hierarchical_data("applications", "2024-01-01")
        assert len(result) == 1
        assert result[0]['id'] == 'app_001'
        assert 'children' in result[0]

@pytest.mark.asyncio
async def test_fetch_hierarchical_data_error(veeva_client):
    with patch.object(veeva_client, '_fetch_data') as mock_fetch:
        mock_fetch.side_effect = Exception("API Error")
        with pytest.raises(Exception) as exc_info:
            await veeva_client.fetch_hierarchical_data("applications", "2024-01-01")
        assert str(exc_info.value) == "API Error"
