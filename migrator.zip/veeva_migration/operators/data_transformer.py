import json
import os
from typing import Dict, Any, List, Optional
import pandas as pd
from datetime import datetime
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from utils.logger import PipelineLogger
from utils.schema_validator import SchemaValidator

logger = PipelineLogger("data_transformer")

class DataTransformer(BaseOperator):
    @apply_defaults
    def __init__(
        self,
        input_file: str,
        output_path: str,
        table_name: str,
        custom_transformations: Optional[Dict[str, callable]] = None,
        *args,
        **kwargs
    ) -> None:
        super().__init__(*args, **kwargs)
        self.input_file = input_file
        self.output_path = output_path
        self.table_name = table_name
        self.custom_transformations = custom_transformations or {}
        self.schema_validator = SchemaValidator()

    def _load_json_data(self) -> List[Dict[str, Any]]:
        """Load data from JSON file."""
        try:
            with open(self.input_file, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error("Failed to load JSON data", {"error": str(e), "file": self.input_file})
            raise

    def _flatten_nested_dict(self, d: Dict[str, Any], parent_key: str = '') -> Dict[str, Any]:
        """Flatten nested dictionary structure."""
        items: List[tuple] = []
        for k, v in d.items():
            new_key = f"{parent_key}_{k}" if parent_key else k

            if isinstance(v, dict):
                items.extend(self._flatten_nested_dict(v, new_key).items())
            elif isinstance(v, list):
                if all(isinstance(x, dict) for x in v):
                    # Handle list of dictionaries
                    for i, item in enumerate(v):
                        items.extend(self._flatten_nested_dict(item, f"{new_key}_{i}").items())
                else:
                    # Convert list to string representation
                    items.append((new_key, ', '.join(str(x) for x in v)))
            else:
                items.append((new_key, v))
        return dict(items)

    def _handle_children_data(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Process and flatten child records."""
        processed_data = []
        
        for record in data:
            flat_record = {k: v for k, v in record.items() if k != 'children'}
            
            if 'children' in record:
                for child_type, children in record['children'].items():
                    for i, child in enumerate(children):
                        child_record = flat_record.copy()
                        child_record.update(
                            self._flatten_nested_dict(child, f"{child_type}")
                        )
                        processed_data.append(child_record)
            else:
                processed_data.append(flat_record)
                
        return processed_data

    def _standardize_column_names(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardize column names to snake_case."""
        df.columns = (
            df.columns
            .str.lower()
            .str.replace(' ', '_')
            .str.replace('-', '_')
            .str.replace('/', '_')
            .str.replace('__', '_')
        )
        return df

    def _apply_custom_transformations(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply custom transformations to specific columns."""
        for column, transformation in self.custom_transformations.items():
            if column in df.columns:
                try:
                    df[column] = df[column].apply(transformation)
                except Exception as e:
                    logger.error(
                        f"Failed to apply transformation to column {column}",
                        {"error": str(e)}
                    )
        return df

    def _handle_date_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """Convert date columns to standard format."""
        date_columns = [
            col for col in df.columns 
            if any(date_indicator in col.lower() 
                  for date_indicator in ['date', 'created', 'modified'])
        ]
        
        for col in date_columns:
            try:
                df[col] = pd.to_datetime(df[col]).dt.strftime('%Y-%m-%d %H:%M:%S')
            except Exception as e:
                logger.warning(
                    f"Failed to convert column {col} to datetime",
                    {"error": str(e)}
                )
        return df

    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing values based on column type."""
        for column in df.columns:
            if df[column].dtype == 'object':
                df[column] = df[column].fillna('N/A')
            elif df[column].dtype in ['int64', 'float64']:
                df[column] = df[column].fillna(-1)
            elif df[column].dtype == 'bool':
                df[column] = df[column].fillna(False)
        return df

    def _transform_data(self, data: List[Dict[str, Any]]) -> pd.DataFrame:
        """Transform raw data into a pandas DataFrame."""
        try:
            # Handle nested child records
            processed_data = self._handle_children_data(data)
            
            # Convert to DataFrame
            df = pd.DataFrame(processed_data)
            
            # Standardize column names
            df = self._standardize_column_names(df)
            
            # Handle date columns
            df = self._handle_date_columns(df)
            
            # Apply custom transformations
            df = self._apply_custom_transformations(df)
            
            # Handle missing values
            df = self._handle_missing_values(df)
            
            # Clean and validate data
            df = self.schema_validator.clean_data(df, self.table_name)
            
            is_valid, error_msg = self.schema_validator.validate_schema(df, self.table_name)
            if not is_valid:
                logger.error("Schema validation failed", {"error": error_msg})
                raise ValueError(f"Schema validation failed: {error_msg}")
            
            return df
            
        except Exception as e:
            logger.error("Failed to transform data", {"error": str(e)})
            raise

    def execute(self, context: Dict[str, Any]) -> None:
        """Execute the operator."""
        try:
            # Load data
            raw_data = self._load_json_data()
            
            # Transform data
            transformed_df = self._transform_data(raw_data)
            
            # Create output directory if it doesn't exist
            os.makedirs(self.output_path, exist_ok=True)
            
            # Save transformed data
            output_file = os.path.join(
                self.output_path,
                f"{self.table_name}_transformed_{datetime.now().strftime('%Y%m%d')}.csv"
            )
            
            transformed_df.to_csv(output_file, index=False)
            
            logger.info("Successfully transformed data", {
                "input_records": len(raw_data),
                "output_records": len(transformed_df),
                "output_file": output_file
            })
            
            # Push output location to XCom
            context['task_instance'].xcom_push(
                key=f'{self.table_name}_transformed_file',
                value=output_file
            )
            
        except Exception as e:
            logger.error("Failed to transform data", {"error": str(e)})
            raise