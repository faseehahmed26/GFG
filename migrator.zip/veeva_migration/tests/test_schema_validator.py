# tests/test_schema_validator.py
import pytest
import pandas as pd
from utils.schema_validator import SchemaValidator

def test_schema_validation():
    validator = SchemaValidator()
    
    test_df = pd.DataFrame({
        'application_id': ['1', '2'],
        'name': ['Test1', 'Test2'],
        'modified_date__v': ['2024-01-01', '2024-01-02'],
        'status__v': ['Active', 'Inactive']
    })
    
    is_valid, error = validator.validate_schema(test_df, 'applications')
    assert is_valid
    assert error is None

def test_schema_validation_missing_column():
    validator = SchemaValidator()
    
    test_df = pd.DataFrame({
        'application_id': ['1', '2'],
        'name': ['Test1', 'Test2']
    })
    
    is_valid, error = validator.validate_schema(test_df, 'applications')
    assert not is_valid
    assert 'Missing required columns' in error