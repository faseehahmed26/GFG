 
### app/routes/pipeline.py ###
from flask import Blueprint, request, jsonify
from app.services import VeevaClient, DataProcessor, RedshiftClient

bp = Blueprint('pipeline', __name__)

@bp.route('/run', methods=['POST'])
async def run_pipeline():
    """Run the complete data pipeline"""
    try:
        data = request.json
        start_date = data.get('start_date')
        root_type = data.get('root_type')

        # Extract
        veeva_client = VeevaClient(config.VEEVA_URL, config.VEEVA_TOKEN)
        raw_data = await veeva_client.fetch_hierarchical_data(root_type, start_date)

        # Process
        processor = DataProcessor(config.RAW_DIR, config.PROCESSED_DIR)
        processed_path = processor.process_data(raw_data, root_type)

        # Load
        redshift = RedshiftClient(config.REDSHIFT_CONN)
        await redshift.append_data(f"{root_type}_table", processed_path)

        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500