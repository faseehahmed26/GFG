from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.models import Variable
from operators.veeva_extractor import VeevaExtractor
from operators.data_transformer import DataTransformer
from operators.redshift_loader import RedshiftLoader

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'veeva_migration',
    default_args=default_args,
    description='Veeva to Redshift Data Migration Pipeline',
    schedule_interval='0 0 * * 0',  # Weekly at midnight on Sunday
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['veeva', 'redshift', 'etl'],
)

# Define endpoints to process
ENDPOINTS = ['applications', 'products', 'submissions']

def create_endpoint_tasks(endpoint):
    """Create extract, transform, and load tasks for an endpoint."""
    
    # Extract task
    extract = VeevaExtractor(
        task_id=f'extract_{endpoint}',
        endpoint=endpoint,
        config_path='/opt/airflow/dags/config/endpoints.yaml',
        output_path=f'/opt/airflow/data/raw/{datetime.now().strftime("%Y%m%d")}',
        last_snapshot_date=Variable.get(f'last_snapshot_date_{endpoint}', default_var=None),
        dag=dag,
    )
    
    # Transform task
    transform = DataTransformer(
        task_id=f'transform_{endpoint}',
        input_file=f'/opt/airflow/data/raw/{datetime.now().strftime("%Y%m%d")}/{endpoint}.json',
        output_path=f'/opt/airflow/data/processed/{datetime.now().strftime("%Y%m%d")}',
        table_name=endpoint,
        dag=dag,
    )
    
    # Load task
    load = RedshiftLoader(
        task_id=f'load_{endpoint}',
        input_file=f'/opt/airflow/data/processed/{datetime.now().strftime("%Y%m%d")}/{endpoint}_transformed.csv',
        table_name=endpoint,
        schema='data_quality',
        redshift_conn_id='redshift_default',
        load_mode='append',
        dag=dag,
    )
    
    # Set dependencies
    extract >> transform >> load
    
    return extract, transform, load

# Create tasks for each endpoint
for endpoint in ENDPOINTS:
    create_endpoint_tasks(endpoint)

def update_snapshot_dates(context):
    """Update last snapshot dates in Airflow variables."""
    current_date = datetime.now().strftime('%Y-%m-%d')
    for endpoint in ENDPOINTS:
        Variable.set(f'last_snapshot_date_{endpoint}', current_date)

# Add task to update snapshot dates
update_dates = PythonOperator(
    task_id='update_snapshot_dates',
    python_callable=update_snapshot_dates,
    dag=dag,
)

# Set this task to run after all endpoint tasks are complete
for endpoint in ENDPOINTS:
    load_task = dag.get_task(f'load_{endpoint}')
    load_task >> update_dates