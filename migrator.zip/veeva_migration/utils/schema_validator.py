from typing import Dict, List, Any, Optional
import pandas as pd
from utils.logger import PipelineLogger

logger = PipelineLogger("schema_validator")

class SchemaValidator:
    def __init__(self):
        self.required_schemas = {
            'applications': {
                'application_id': str,
                'name': str,
                'modified_date__v': str,
                'status__v': str
            },
            'products': {
                'product_id': str,
                'application_id': str,
                'name': str,
                'modified_date__v': str
            }
        }

    def validate_schema(self, data: pd.DataFrame, table_name: str) -> tuple[bool, Optional[str]]:
        """
        Validates if the DataFrame matches the required schema for a given table.
        
        Args:
            data: DataFrame to validate
            table_name: Name of the table schema to validate against
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if table_name not in self.required_schemas:
            return False, f"No schema defined for table {table_name}"

        required_columns = set(self.required_schemas[table_name].keys())
        actual_columns = set(data.columns)

        # Check for missing required columns
        missing_columns = required_columns - actual_columns
        if missing_columns:
            return False, f"Missing required columns: {missing_columns}"

        # Validate data types
        for column, expected_type in self.required_schemas[table_name].items():
            try:
                if expected_type == str:
                    data[column] = data[column].astype(str)
                elif expected_type == int:
                    pd.to_numeric(data[column], errors='raise')
            except Exception as e:
                return False, f"Data type validation failed for column {column}: {str(e)}"

        return True, None

    def clean_data(self, data: pd.DataFrame, table_name: str) -> pd.DataFrame:
        """
        Cleans and standardizes data according to schema requirements.
        
        Args:
            data: DataFrame to clean
            table_name: Name of the table schema to use
            
        Returns:
            Cleaned DataFrame
        """
        if table_name not in self.required_schemas:
            logger.warning(f"No schema defined for table {table_name}, returning original data")
            return data

        cleaned_data = data.copy()

        # Handle missing values
        cleaned_data = cleaned_data.fillna({
            col: 'N/A' if dtype == str else -1 
            for col, dtype in self.required_schemas[table_name].items()
        })

        # Convert types according to schema
        for column, expected_type in self.required_schemas[table_name].items():
            if column in cleaned_data.columns:
                try:
                    if expected_type == str:
                        cleaned_data[column] = cleaned_data[column].astype(str)
                    elif expected_type == int:
                        cleaned_data[column] = pd.to_numeric(cleaned_data[column], errors='coerce')
                except Exception as e:
                    logger.error(f"Error cleaning column {column}", {"error": str(e)})

        return cleaned_data