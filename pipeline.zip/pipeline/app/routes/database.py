 
# app/routes/database.py
from flask import Blueprint, request, jsonify
from app.services.redshift_client import RedshiftClient
from app.utils.validators import validate_schema_compatibility
from app.utils.logger import setup_logger

logger = setup_logger('database_routes')
bp = Blueprint('database', __name__)

@bp.route('/database', methods=['POST'])
async def create_database():
    try:
        data = request.json
        client = RedshiftClient()
        await client.create_database(data['name'])
        return jsonify({"status": "success"})
    except Exception as e:
        logger.error(f"Database creation failed: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500

@bp.route('/table', methods=['POST'])
async def create_table():
    try:
        data = request.json
        client = RedshiftClient()
        await client.create_table(data['name'], data['schema'])
        return jsonify({"status": "success"})
    except Exception as e:
        logger.error(f"Table creation failed: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500

@bp.route('/table/<table_name>', methods=['DELETE'])
async def remove_table(table_name):
    try:
        client = RedshiftClient()
        await client.backup_and_remove_table(table_name)
        return jsonify({"status": "success"})
    except Exception as e:
        logger.error(f"Table removal failed: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500
