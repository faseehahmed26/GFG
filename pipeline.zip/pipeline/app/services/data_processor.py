 
### app/services/data_processor.py ###
import pandas as pd
from app.utils.logger import setup_logger
from time import datetime
logger = setup_logger('data_processor')

class DataProcessor:
    def __init__(self, raw_dir, processed_dir):
        self.raw_dir = raw_dir
        self.processed_dir = processed_dir

    def process_data(self, data, data_type):
        """Process and transform raw data"""
        try:
            df = pd.DataFrame(data)
            
            # Normalize column names
            df.columns = [col.lower().replace(' ', '_') for col in df.columns]
            
            # Handle null values
            df = df.fillna({'string_cols': '', 'numeric_cols': 0})
            
            # Save processed data
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_path = f"{self.processed_dir}/{data_type}_{timestamp}.csv"
            df.to_csv(output_path, index=False)
            
            return output_path
        except Exception as e:
            logger.error(f"Error processing data: {str(e)}")
            raise