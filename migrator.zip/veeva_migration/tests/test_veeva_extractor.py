# tests/test_veeva_extractor.py
import pytest
from unittest.mock import Mock, patch
from operators.veeva_extractor import VeevaExtractor

@pytest.fixture
def mock_config():
    return {
        'veeva_api': {
            'base_url': 'http://test.api',
            'version': 'v1',
            'endpoints': {
                'applications': {
                    'path': '/applications'
                }
            }
        }
    }

def test_veeva_extractor_init():
    extractor = VeevaExtractor(
        task_id='test',
        endpoint='applications',
        config_path='test/config.yaml',
        output_path='test/output'
    )
    assert extractor.endpoint == 'applications'
    assert extractor.output_path == 'test/output'

@patch('operators.veeva_extractor.requests.Session')
def test_make_api_request(mock_session):
    mock_response = Mock()
    mock_response.json.return_value = {'data': []}
    mock_session.return_value.get.return_value = mock_response
    
    extractor = VeevaExtractor(
        task_id='test',
        endpoint='applications',
        config_path='test/config.yaml',
        output_path='test/output'
    )
    result = extractor._make_api_request('http://test.url', {})
    assert result == {'data': []}