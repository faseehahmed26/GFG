# app/__init__.py
from flask import Flask
from app.config import Config
from app.routes import pipeline, database

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Register blueprints
    app.register_blueprint(pipeline.bp, url_prefix='/api/pipeline')
    app.register_blueprint(database.bp, url_prefix='/api/database')
    
    return app