# dags/config/__init__.py
"""
Configuration package for DAGs.
"""
from pathlib import Path

CONFIG_DIR = Path(__file__).parent
ENDPOINTS_CONFIG = CONFIG_DIR / 'endpoints.yaml'

__all__ = ['CONFIG_DIR', 'ENDPOINTS_CONFIG']
