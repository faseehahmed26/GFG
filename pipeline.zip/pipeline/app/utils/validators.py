 
# app/utils/validators.py
from datetime import datetime
import pandas as pd

def validate_date_format(date_str):
    try:
        return datetime.strptime(date_str, '%Y-%m-%d')
    except ValueError:
        raise ValueError("Invalid date format. Use YYYY-MM-DD")

def validate_schema_compatibility(df, existing_schema):
    df_dtypes = df.dtypes.to_dict()
    for col, dtype in existing_schema.items():
        if col not in df_dtypes:
            raise ValueError(f"Missing column: {col}")
        if not pd.api.types.is_dtype_equal(df_dtypes[col], dtype):
            raise ValueError(f"Schema mismatch for column: {col}")
