 
# tests/test_redshift_client.py
import pytest
import pandas as pd
from unittest.mock import patch, MagicMock
from app.services.redshift_client import RedshiftClient

@pytest.fixture
def redshift_client():
    return RedshiftClient("mock_connection_string")

@pytest.fixture
def sample_df():
    return pd.DataFrame({
        'id': ['app_001'],
        'name': ['Test Application'],
        'status': ['Active']
    })

@pytest.mark.asyncio
async def test_create_table_success(redshift_client):
    mock_conn = MagicMock()
    mock_conn.__aenter__ = MagicMock(return_value=mock_conn)
    mock_conn.__aexit__ = MagicMock(return_value=None)
    
    with patch.object(redshift_client, '_get_connection', return_value=mock_conn):
        await redshift_client.create_table("test_table", {"id": "VARCHAR(255)"})
        mock_conn.execute.assert_called_once()
        assert "CREATE TABLE test_table" in mock_conn.execute.call_args[0][0]

@pytest.mark.asyncio
async def test_append_data_success(redshift_client, sample_df):
    with tempfile.NamedTemporaryFile(suffix='.csv') as tf:
        sample_df.to_csv(tf.name, index=False)
        
        mock_conn = MagicMock()
        mock_conn.__aenter__ = MagicMock(return_value=mock_conn)
        mock_conn.__aexit__ = MagicMock(return_value=None)
        
        with patch.object(redshift_client, '_get_connection', return_value=mock_conn):
            with patch.object(redshift_client, '_backup_table'):
                await redshift_client.append_data("test_table", tf.name)
                mock_conn.execute.assert_called_once()
                assert "COPY test_table" in mock_conn.execute.call_args[0][0]
